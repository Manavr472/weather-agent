/** @type {import('tailwindcss').Config} */
module.exports = {
  mode: 'jit',
  content: [
    './src/**/*.{js,ts,jsx,tsx}',
    './public/**/*.html',
  ],
  theme: {
    extend: {
      colors: {
        background: '#1a1a1a',
        foreground: '#f2f2f2',
      },
    },
  },
  darkMode: 'class',
  plugins: [],
};
