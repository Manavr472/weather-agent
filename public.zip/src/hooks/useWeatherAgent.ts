import { useState, useEffect, useRef } from "react";

interface UseWeatherAgentParams {
  messageHistory: { sender: string; text: string }[];
  threadId: string;
  apiUrl: string;
}

const useWeatherAgent = ({ messageHistory, threadId, apiUrl }: UseWeatherAgentParams) => {
  const [responseChunks, setResponseChunks] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  // Parse the streaming response format
  const parseStreamChunk = (chunk: string) => {
    try {
      // The response comes in lines, each potentially containing multiple parts
      const lines = chunk.trim().split('\n');
      
      let extractedText = '';
      
      for (const line of lines) {
        // Extract content parts that contain 0:" pattern (message content)
        const regex = /0:"([^"]*)"/g;
        let match;
        while ((match = regex.exec(line)) !== null) {
          // This is necessary to avoid infinite loops with zero-width matches
          if (match.index === regex.lastIndex) {
            regex.lastIndex++;
          }
          
          // Extract the content between quotes
          if (match[1]) {
            extractedText += match[1];
          }
        }
      }
      
      return extractedText;
    } catch (err) {
      console.error('Error parsing stream chunk:', err);
      return chunk; // Return the original chunk if parsing fails
    }
  };

  const sendRequest = async () => {
    setLoading(true);
    setError(null);
    setResponseChunks([]);

    abortControllerRef.current = new AbortController();

    try {
      // Format messages according to the API specification
      // First, make sure we're only sending relevant messages (user and agent)
      // and correctly format them for the API
      const formattedMessages = messageHistory
        .filter(msg => msg.sender === "user" || msg.sender === "agent")
        .map(msg => ({
          role: msg.sender === "user" ? "user" : "assistant",
          content: msg.text
        }));

      // Ensure the conversation has at least one message
      if (formattedMessages.length === 0) {
        formattedMessages.push({
          role: "user",
          content: "Hello, can you help me with weather information?"
        });
      }

      console.log("Formatted messages for API:", formattedMessages);
      
      const requestBody = {
        messages: formattedMessages,
        runId: "weatherAgent",
        maxRetries: 2,
        maxSteps: 5,
        temperature: 0.5,
        topP: 1,
        runtimeContext: {},
        threadId,
      };
      
      console.log("API Request body:", requestBody);

      const response = await fetch(apiUrl, {
        method: "POST",
        headers: {
          'Accept': '*/*',
          'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8,fr;q=0.7',
          'Connection': 'keep-alive',
          'Content-Type': 'application/json',
          'x-mastra-dev-playground': 'true'
        },
        body: JSON.stringify(requestBody),
        signal: abortControllerRef.current.signal,
      });

      console.log("API Response status:", response.status);
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error("API Error response:", errorText);
        throw new Error(`API error: ${response.status} ${errorText}`);
      }

      if (!response.body) {
        throw new Error("No response body");
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder("utf-8");
      let fullMessage = '';
      let chunkCount = 0;

      while (true) {
        const { done, value } = await reader.read();
        if (done) {
          console.log("Stream reading complete, final message:", fullMessage);
          break;
        }
        
        const chunk = decoder.decode(value);
        console.log(`Raw chunk ${++chunkCount}:`, chunk);
        
        const parsedChunk = parseStreamChunk(chunk);
        console.log(`Parsed chunk ${chunkCount}:`, parsedChunk);
        
        if (parsedChunk.trim()) {
          // Preserve markdown formatting in the response
          fullMessage += parsedChunk;
          
          // Update with the full message so far to show progressive updates
          console.log("Setting responseChunks with:", fullMessage);
          
          // Make sure we're not corrupting any markdown symbols
          setResponseChunks([fullMessage]);
        }
      }
    } catch (err: any) {
      if (err.name === "AbortError") {
        console.log("Request aborted");
      } else {
        setError(err.message);
      }
    } finally {
      setLoading(false);
    }
  };

  const abortRequest = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
  };

  useEffect(() => {
    return () => {
      abortRequest();
    };
  }, []);

  return { responseChunks, loading, error, sendRequest, abortRequest };
};

export default useWeatherAgent;
