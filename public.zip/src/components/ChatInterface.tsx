"use client"
import React, { useState, useRef, useEffect } from "react";
import ReactMarkdown from "react-markdown";
import useWeatherAgent from "../hooks/useWeatherAgent";
import "../app/markdown-styles.css";

// Thread ID management - Could be moved to a utility file
const THREAD_ID_KEY = "weather_agent_thread_id";
const getThreadId = () => {
  // Use college roll number or generate a UUID if not available
  return localStorage.getItem(THREAD_ID_KEY) || `thread-${Date.now()}`;
};

const saveThreadId = (threadId: string) => {
  localStorage.setItem(THREAD_ID_KEY, threadId);
};

const ChatInterface: React.FC = () => {
  const [messages, setMessages] = useState<Array<{ sender: string; text: string }>>([
    { sender: "agent", text: "Hello! I'm your weather assistant. Ask me about weather conditions anywhere!" },
  ]);
  const [input, setInput] = useState("");
  const [theme, setTheme] = useState("light");
  const [threadId, setThreadId] = useState("");
  const chatHistoryRef = useRef<HTMLDivElement>(null);
  const lastResponseRef = useRef<string>("");

  // Initialize thread ID on component mount
  useEffect(() => {
    const currentThreadId = getThreadId();
    setThreadId(currentThreadId);
    saveThreadId(currentThreadId);

    // Load saved messages for this thread (if any)
    const savedMessages = localStorage.getItem(`messages_${currentThreadId}`);
    if (savedMessages) {
      setMessages(JSON.parse(savedMessages));
    }

    const storedTheme = localStorage.getItem("theme") || "light";
    setTheme(storedTheme);
    document.documentElement.classList.toggle("dark", storedTheme === "dark");
  }, []);

  // Save messages whenever they change
  useEffect(() => {
    if (threadId && messages.length > 0) {
      localStorage.setItem(`messages_${threadId}`, JSON.stringify(messages));
    }
  }, [messages, threadId]);

  const { responseChunks, loading, error, sendRequest } = useWeatherAgent({
    messageHistory: messages.filter(msg => msg.sender !== "system"),
    threadId: threadId,
    apiUrl: "https://brief-thousands-sunset-9fcb1c78-485f-4967-ac04-2759a8fa1462.mastra.cloud/api/agents/weatherAgent/stream",
  });

  const sendMessage = () => {
    if (input.trim() && !loading) {
      const userMessage = { sender: "user", text: input };
      setMessages([...messages, userMessage]);
      setInput("");
      console.log("Sending message to API:", userMessage);
      console.log("Current thread ID:", threadId);
      sendRequest();
    } else if (!input.trim()) {
      setMessages([
        ...messages,
        { sender: "system", text: "Message cannot be empty." },
      ]);
    }
  };

  const clearChat = () => {
    // Generate a new thread ID
    const newThreadId = `thread-${Date.now()}`;
    setThreadId(newThreadId);
    saveThreadId(newThreadId);

    // Reset messages to initial state
    setMessages([
      { sender: "agent", text: "Hello! I'm your weather assistant. Ask me about weather conditions anywhere!" },
    ]);

    // Clear old thread messages from localStorage
    localStorage.removeItem(`messages_${threadId}`);
  };

  const toggleTheme = () => {
    const newTheme = theme === "light" ? "dark" : "light";
    setTheme(newTheme);
    localStorage.setItem("theme", newTheme);
    document.documentElement.classList.toggle("dark", newTheme === "dark");
  };

  useEffect(() => {
    console.log("responseChunks changed:", responseChunks);
    
    if (responseChunks.length > 0 && responseChunks[0].trim()) {
      console.log("Processing response chunk:", responseChunks[0]);
      console.log("Last response ref:", lastResponseRef.current);
      
      // Check if the response is substantially different or just growing
      const isNewResponse = !responseChunks[0].startsWith(lastResponseRef.current) && 
                          !lastResponseRef.current.startsWith(responseChunks[0]);
      
      // Only update if the response has changed
      if (responseChunks[0] !== lastResponseRef.current) {
        console.log("Response changed, updating messages");
        lastResponseRef.current = responseChunks[0];
        
        setMessages(prev => {
          console.log("Previous messages:", prev);
          const lastUserMsgIndex = [...prev].reverse().findIndex(msg => msg.sender === "user");
          const lastAgentMsgIndex = [...prev].reverse().findIndex(msg => msg.sender === "agent" && !msg.text.includes("Hello"));
          
          // If we have a user message and either no agent message or the agent message is before the last user message
          if (lastUserMsgIndex !== -1 && (lastAgentMsgIndex === -1 || lastUserMsgIndex < lastAgentMsgIndex)) {
            // Add new agent message after the user message
            console.log("Adding new agent message after user message");
            return [
              ...prev,
              { sender: "agent", text: responseChunks[0] }
            ];
          }
          // If we already have an agent message and are just updating it
          else if (lastAgentMsgIndex !== -1) {
            const reverseIndex = lastAgentMsgIndex;
            const actualIndex = prev.length - 1 - reverseIndex;
            
            console.log("Updating existing agent message at index:", actualIndex);
            const updatedMessages = [...prev];
            updatedMessages[actualIndex] = { sender: "agent", text: responseChunks[0] };
            return updatedMessages;
          }
          // Fallback - add new agent message
          else if (isNewResponse) {
            console.log("Adding new agent message (fallback)");
            return [
              ...prev,
              { sender: "agent", text: responseChunks[0] }
            ];
          }
          
          console.log("No message update needed");
          return prev; // No change
        });
      }
    }
  }, [responseChunks, loading]);

  useEffect(() => {
    if (error) {
      setMessages((prev) => [...prev, { sender: "system", text: `Error: ${error}` }]);
    }
  }, [error]);

  useEffect(() => {
    if (chatHistoryRef.current) {
      chatHistoryRef.current.scrollTop = chatHistoryRef.current.scrollHeight;
    }
  }, [messages]);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark");
  }, [theme]);

  // Handle Enter key press
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div className="flex flex-col h-screen transition-colors duration-300">
      {/* Header with Theme toggle and Clear Chat buttons */}
      <div className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2 bg-white dark:bg-gray-900 border-b border-gray-300 dark:border-gray-700">
        <span className="text-lg font-semibold text-gray-800 dark:text-gray-200">
          Weather Agent Chat - {theme.charAt(0).toUpperCase() + theme.slice(1)} Mode
        </span>
        <div className="flex gap-2">
          <button
            onClick={clearChat}
            className="px-4 py-2 rounded-lg border border-red-300 dark:border-red-700 bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-200 hover:bg-red-200 dark:hover:bg-red-800 focus:outline-none focus:ring-2 focus:ring-red-500 dark:focus:ring-red-400 transition-transform"
            aria-label="Clear chat history"
          >
            New Chat
          </button>
          <button
            onClick={toggleTheme}
            aria-label={`Switch to ${theme === "light" ? "dark" : "light"} mode`}
            className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-100 dark:bg-gray-800 text-black dark:text-white hover:bg-gray-200 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 transition-transform"
          >
            {theme === "light" ? "Dark Mode" : "Light Mode"}
          </button>
        </div>
      </div>

      {/* Chat history pane */}
      <div
        ref={chatHistoryRef}
        className="flex-1 overflow-y-auto p-4 bg-gray-100 dark:bg-gray-800 flex flex-col"
      >
        {messages.map((message, index) => (
          <div
            key={index}
            className={`mb-4 p-3 rounded-lg max-w-[75%] ${
              message.sender === "user"
                ? "self-end bg-blue-500 text-white ml-auto"
                : message.sender === "agent"
                ? "self-start bg-gray-300 text-black dark:bg-gray-700 dark:text-white agent-message"
                : "self-start bg-red-500 text-white"
            }`}
          >
            {message.sender === "agent" ? (
              <ReactMarkdown>{message.text}</ReactMarkdown>
            ) : (
              message.text
            )}
          </div>
        ))}
        {loading && (
          <div className="self-start bg-gray-300 text-black dark:bg-gray-700 dark:text-white p-3 rounded-lg max-w-[75%] flex items-center gap-2">
            Typing
            <span className="animate-pulse">...</span>
          </div>
        )}
      </div>

      {/* Message input */}
      <div className="flex items-center p-4 bg-white dark:bg-gray-900 border-t border-gray-300 dark:border-gray-700">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          className="flex-1 p-2 rounded-lg border border-gray-300 dark:border-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 bg-white dark:bg-gray-800 text-black dark:text-white"
          placeholder="Ask about weather conditions..."
          disabled={loading}
        />
        <button
          onClick={sendMessage}
          className={`ml-4 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 transition-all ${loading ? 'opacity-50 cursor-not-allowed' : ''}`}
          disabled={loading}
        >
          Send
        </button>
      </div>
    </div>
  );
};

export default ChatInterface;
